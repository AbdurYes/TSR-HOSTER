 document.getElementById('year').textContent = new Date().getFullYear();
 
  function handleSearch(event) {
    event.preventDefault();
    const domain = document.getElementById('domainInput').value.trim();
    if (domain) {
      const url = `https://client.tsrhoster.com/cart.php?a=add&domain=register&query=${encodeURIComponent(domain)}`;
      window.location.href = url;
    }
  }